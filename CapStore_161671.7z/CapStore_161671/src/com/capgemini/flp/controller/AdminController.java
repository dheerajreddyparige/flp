package com.capgemini.flp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.flp.dto.Customer;
import com.capgemini.flp.dto.Inventory;
import com.capgemini.flp.dto.Merchant;

import com.capgemini.flp.exception.AllException;
import com.capgemini.flp.service.IAdminService;

@Controller

public class AdminController {
	@Autowired
	IAdminService service;
	
	@RequestMapping ("/hi")
	public ModelAndView home(){
		 	return new ModelAndView("adminhome","abc","abc");
	}
	@RequestMapping ("/merchant")
	public ModelAndView merchant(){
		try {List<Merchant> merchantList=service.getAllMerchantDetails();
		if(merchantList.size()!=0) {				
			return new ModelAndView("all_merchants","merchantList",merchantList);
		}else {
			return new ModelAndView("cust_status","message","No customers in database");
		}
	}catch(AllException e) {
		e.printStackTrace();
		return new ModelAndView("status","message",e.getMessage());
	}

		
	}
	@RequestMapping ("/customer")
	public ModelAndView customer(){
		try {
			List<Customer> customerList=service.getAllCustomerDetails();
			if(customerList.size()!=0) {				
				return new ModelAndView("all_customers","customerList",customerList);
			}else {
				return new ModelAndView("cust_status","message","No customers in database");
			}
		}catch(AllException e) {
			e.printStackTrace();
			return new ModelAndView("status","message",e.getMessage());
		}
	}
		
		
		
	
	
	@RequestMapping ("/product")
	public ModelAndView product(){
		try {
			List<Inventory> productList=service.getAllProductDetails();
			if(productList.size()!=0) {				
				return new ModelAndView("products","productList",productList);
			}else {
				return new ModelAndView("cust_status","message","No customers in database");
			}
		}catch(AllException e) {
			e.printStackTrace();
			return new ModelAndView("status","message",e.getMessage());
		}
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	/*
	public ModelAndView showIndex() throws Exception {
		ModelAndView mv=new ModelAndView("index");
		try{
			List<Invoice> invoice=service.getInvoice();
			mv.addObject("invoices",invoice);

		}catch (Exception e){
		 throw new InvoiceException (e.getMessage());
		}
		return mv;
		
	}
	 @RequestMapping("/addInvoice")
	 public ModelAndView showAdd(){
		 
		 ModelAndView mv=new ModelAndView("add");
		 try{
				List<Invoice> invoice=service.getInvoice();
				mv.addObject("invoices",invoice);

			}catch (Exception e){
			 try {
				throw new InvoiceException (e.getMessage());
			} catch (InvoiceException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			}
			return mv;
		 
	 }*/

	/* @RequestMapping("/add")
  public ModelAndView addEmployee(@Valid @ModelAttribute Invoice invoice,BindingResult result){
	  ModelAndView mv=null;
	  
	  if(result.hasErrors()){
		  
		  
		  
		  
		    mv=new  ModelAndView("add");
		   mv.addObject("invoices",invoice);
		   
	  }
	  else{
		   
	  }
	  return mv;
  }
}*/


	/* @RequestMapping("/addEmployee")
	 public String showAdd(Model model){
		 
		 model.addAttribute("employee",new Employee());
		return "add";
		 
	 }
	 @RequestMapping("/add")
  public ModelAndView addEmployee(@Valid @ModelAttribute Employee employee,BindingResult result){
	  ModelAndView mv=null;
	  
	  if(result.hasErrors()){
		  
		  
		  
		  
		    mv=new  ModelAndView("add");
		   mv.addObject("employee",employee);
		   
	  }
	  else{
		   
	  }
	  return mv;
  }*/

