package com.capgemini.flp.service;



import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.flp.dao.IAdminDao;

import com.capgemini.flp.dto.Customer;
import com.capgemini.flp.dto.Merchant;
import com.capgemini.flp.dto.Inventory;
import com.capgemini.flp.exception.AllException;

@Transactional
@Service
public class AdminServiceImpl  implements IAdminService{
	@Autowired
	IAdminDao invoiceDao;

	
	


	@Override
	public List<Customer> getAllCustomerDetails() throws AllException {
		// TODO Auto-generated method stub
		return invoiceDao. getAllCustomerDetails();
	}


	@Override
	public List<Merchant> getAllMerchantDetails() throws AllException {
		// TODO Auto-generated method stub
		return invoiceDao. getAllMerchantDetails();
	}


	@Override
	public List<Inventory> getAllProductDetails() throws AllException {
		return invoiceDao. getAllproductDetails();
	}

}
