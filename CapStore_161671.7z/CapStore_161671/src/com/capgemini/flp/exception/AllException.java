package com.capgemini.flp.exception;

public class AllException extends Exception{
	public AllException(String msg){
		 super(msg);

}
}
