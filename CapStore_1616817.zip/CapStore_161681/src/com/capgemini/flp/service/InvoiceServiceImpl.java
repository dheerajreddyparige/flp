package com.capgemini.flp.service;



import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.flp.dao.InvoiceDao;
import com.capgemini.flp.dto.MerchantProduct;
import com.capgemini.flp.exception.InvoiceException;

@Transactional
@Service
public class InvoiceServiceImpl  implements InvoiceService{
	@Autowired
	InvoiceDao invoiceDao;

	
	@Override
	public MerchantProduct getInvoice(int productid, int orderid) throws InvoiceException {
		return invoiceDao.getInvoice(productid, orderid);
		
	}


	@Override
	public List<MerchantProduct> getAllInvoice() {
		// TODO Auto-generated method stub
		return invoiceDao.getAllInvoice();
	}

	
}
