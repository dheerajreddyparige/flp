package com.capgemini.flp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.flp.dto.MerchantProduct;
import com.capgemini.flp.exception.InvoiceException;
import com.capgemini.flp.service.InvoiceService;

@Controller
public class InvoiceController {
	@Autowired
	InvoiceService service;

	@RequestMapping("/hello")
	public ModelAndView abc() {

		int productid = 354;
		int orderid = 10;

		try {
			MerchantProduct a=service.getInvoice(productid, orderid);
			
			return new ModelAndView("index","mp",a);
		} catch (InvoiceException e) {

		System.out.println(e.getMessage());
		}
		return null;

	}
	@RequestMapping("/index")
	public ModelAndView index() {
		return new ModelAndView("index","mp","");
	}
}
