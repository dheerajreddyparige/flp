package com.capgemini.flp.dao;

import java.util.List;

import com.capgemini.flp.dto.MerchantProduct;
import com.capgemini.flp.exception.InvoiceException;

public interface InvoiceDao {
	public MerchantProduct getInvoice(int productid, int orderid)throws InvoiceException;
}
