package com.capgemini.flp.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;


import com.capgemini.flp.dto.MerchantProduct;
import com.capgemini.flp.exception.InvoiceException;




@Repository
public class InvoiceDaoImpl implements InvoiceDao {
	@PersistenceContext  
	EntityManager entityManager;
		
		
	

	
		@Override
		public MerchantProduct getInvoice(int productid, int orderid)
				throws InvoiceException {
			MerchantProduct a=entityManager.find(MerchantProduct.class,productid);
			//entityManager.find(MerchantProduct.class, productid);
			return a;
		
			
		}
		}


