package com.capgemini.flp.exception;

public class InvoiceException extends Exception{
	public InvoiceException(String msg){
		 super(msg);

}
}
